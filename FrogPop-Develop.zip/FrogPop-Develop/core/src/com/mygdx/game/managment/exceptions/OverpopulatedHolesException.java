package com.mygdx.game.managment.exceptions;

/**
 * Created by MichaelBond on 8/28/2016.
 */
public class OverpopulatedHolesException extends IllegalStateException {

    public OverpopulatedHolesException() {
        super();
    }

    public OverpopulatedHolesException(String message) {
        super(message);
    }
}
